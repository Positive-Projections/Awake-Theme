<?php
/**
 *
 */
class mysiteSocial {

	/**
	 *  ReTweet button
	 */
	static function tweet( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Twitter", 'awake' ),
				"value" => "tweet",
				"options" => array(
					array(
						"name" => __( "Twitter Username", 'awake' ),
						"id" => "username",
						"desc" => __( 'Type out your twitter username here.  You can find your twitter username by logging into your twitter account.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Tweet Position", 'awake' ),
						"id" => "layout",
						"desc" => __( 'Choose whether you want your tweets to display vertically, horizontally, or none at all.', 'awake' ),
						"default" => "",
						"options" => array(
							"vertical" => __( "Vertical", 'awake' ),
							"horizontal" => __( "Horizontal", 'awake' ),
							"none" => __( "None", 'awake' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Custom Text", 'awake' ),
						"id" => "text",
						"desc" => __( 'This is the text that people will include in their Tweet when they share from your website.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Custom URL", 'awake' ),
						"id" => "url",
						"desc" => __( 'By default the URL from your page will be used but you can input a custom URL here.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Related Users", 'awake' ),
						"id" => "related",
						"desc" => __( 'You can input another twitter username for recommendation.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Language", 'awake' ),
						"id" => "lang",
						"desc" => __( 'Select which language you would like to display the button in.', 'awake' ),
						"default" => "",
						"options" => array(
							"fr" => __( "French", 'awake' ),
							"de" => __( "German", 'awake' ),
							"it" => __( "Italian", 'awake' ),
							"ja" => __( "Japanese", 'awake' ),
							"ko" => __( "Korean", 'awake' ),
							"ru" => __( "Russian", 'awake' ),
							"es" => __( "Spanish", 'awake' ),
							"tr" => __( "Turkish", 'awake' ),
						),
						"type" => "select"
					),
					"shortcode_has_atts" => true,
				)
			);

			return $option;
		}
		
		extract(shortcode_atts(array(
			'layout'        => 'vertical',
			'username'		  => '',
			'text' 			  => '',
			'url'			  => '',
			'related'		  => '',
			'lang'			  => '',
	    	), $atts));
	
		if( is_feed() ) return;
	    	
	    if ($text != '') { $text = "data-text='".$text."'"; }
	    if ($url != '') { $url = "data-url='".$url."'"; }
	    if ($related != '') { $related = "data-related='".$related."'"; }
	    if ($lang != '') { $lang = "data-lang='".$lang."'"; }
		
		$out = '<div class = "mysite_sociable"><a href="http://twitter.com/share" class="twitter-share-button" '.$url.' '.$lang.' '.$text.' '.$related.' data-count="'.$layout.'" data-via="'.$username.'">Tweet</a>';
		$out .= '<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script></div>';
		
		return $out;
	}
	
	/**
	 *  Facebook Like button
	 */
	static function fblike( $atts = null, $content = null ) {

	    if( $atts == 'generator' ) {
	        $option = array(
	            "name" => __( "Facebook Like", 'awake' ),
	            "value" => "fblike",
	            "options" => array(
	                array(
	                    "name" => __( "Layout", 'awake' ),
	                    "id" => "layout",
	                    "desc" => __( 'Choose the layout you would like to use with your facebook button.', 'awake' ),
	                    "default" => "",
	                    "options" => array(
	                        "standard" => __( "Standard", 'awake' ),
	                        "box_count" => __( "Box Count", 'awake' ),
	                        "button_count" => __( "Button Count", 'awake' ),
	                    ),
	                    "type" => "select"
	                ),
	                array(
	                    "name" => __( "Add send button?", 'awake' ),
	                    "id" => "send",
	                    "desc" => __( 'Check to add the send button alongside the like button.', 'awake' ),
	                    'options' => array( 'true' => __( 'Yes', 'awake' )),
	                    'default' => '',
	                    'type' => 'checkbox'
	                ),
	                array(
	                    "name" => __( "Show Faces?", 'awake' ),
	                    "id" => "show_faces",
	                    "desc" => __( 'Check to display faces.', 'awake' ),
	                    'options' => array( 'true' => __( 'Yes', 'awake' )),
	                    'default' => '',
	                    'type' => 'checkbox'
	                ),
	                array(
	                    "name" => __( "Action", 'awake' ),
	                    "id" => "action",
	                    "desc" => __( 'This is the text that gets displayed on the button.', 'awake' ),
	                    "default" => "",
	                    "options" => array(
	                        "like" => __( "Like", 'awake' ),
	                        "recommend" => __( "Recommend", 'awake' ),
	                    ),
	                    "type" => "select"
	                ),
	                array(
	                    "name" => __( "Font", 'awake' ),
	                    "id" => "font",
	                    "desc" => __( 'Select which font you would like to use.', 'awake' ),
	                    "default" => "",
	                    "options" => array(
	                        "lucida+grande" => __( "Lucida Grande", 'awake' ),
	                        "arial" => __( "Arial", 'awake' ),
	                        "segoe+ui" => __( "Segoe Ui", 'awake' ),
	                        "tahoma" => __( "Tahoma", 'awake' ),
	                        "trebuchet+ms" => __( "Trebuchet MS", 'awake' ),
	                        "verdana" => __( "Verdana", 'awake' ),
	                    ),
	                    "type" => "select"
	                ),
	                array(
	                    "name" => __( "Color Scheme", 'awake' ),
	                    "id" => "colorscheme",
	                    "desc" => __( 'Select the color scheme you would like to use.', 'awake' ),
	                    "default" => "",
	                    "options" => array(
	                        "light" => __( "Light", 'awake' ),
	                        "dark" => __( "Dark", 'awake' ),
	                    ),
	                    "type" => "select"
	                ),
	                "shortcode_has_atts" => true,
	            )
	        );

	        return $option;
	    }

	    extract(shortcode_atts(array(
	            'layout'        => 'box_count',
	            'width'            => '',
	            'height'        => '',
	            'send'            => false,
	            'show_faces'    => false,
	            'action'        => 'like',
	            'font'            => 'lucida+grande',
	            'colorscheme'    => 'light',
	        ), $atts));

	    if( is_feed() ) return;

	    if ($layout == 'standard') { $width = '450'; $height = '35';  if ($show_faces == 'true') { $height = '80'; } }
	    if ($layout == 'box_count') { $width = '55'; $height = '65'; }
	    if ($layout == 'button_count') { $width = '90'; $height = '20'; }

	    $layout = 'data-layout = "'.$layout.'"';
	    $width = 'data-width = "'.$width.'"';
	    $font = 'data-font = "'.str_replace("+", " ", $font).'"';
	    $colorscheme = 'data-colorscheme = "'.$colorscheme.'"';
	    $action = 'data-action = "'.$action.'"';
	    if ( $show_faces ) { $show_faces = 'data-show-faces = "true"'; } else { $show_faces = ''; }
	    if ( $send ) { $send = 'data-send = "true"'; } else { $send = ''; }

	    $out = '<div class = "mysite_sociable">';
	    $out .= '<div id="fb-root"></div><script>(function(d, s, id) {var js, fjs = d.getElementsByTagName(s)[0];if (d.getElementById(id)) return;js = d.createElement(s); js.id = id;js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";fjs.parentNode.insertBefore(js, fjs);}(document, "script", "facebook-jssdk"));</script>';
	    $out .= '<div class = "fb-like" data-href = "'.get_permalink().'" '.$layout.$width.$font.$colorscheme.$action.$show_faces.$send.'></div>';
	    $out .= '</div>';

	    return $out;
	}
	
	
	/**
	 *  Google +1
	 */
	static function googleplusone( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Google +1", 'awake' ),
				"value" => "googleplusone",
				"options" => array(
					array(
						"name" => __( "Size", 'awake' ),
						"id" => "size",
						"desc" => __( 'Choose how you would like to display the google plus button.', 'awake' ),
						"default" => "",
						"options" => array(
							"small" => __( "Small", 'awake' ),
							"standard" => __( "Standard", 'awake' ),
							"medium" => __( "Medium", 'awake' ),
							"tall" => __( "Tall", 'awake' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Language", 'awake' ),
						"id" => "lang",
						"desc" => __( 'Select which language you would like to display the button in.', 'awake' ),
						"default" => "",
						"options" => array(
							"ar" => __( "Arabic", 'awake' ),
							"bn" => __( "Bengali", 'awake' ),
							"bg" => __( "Bulgarian", 'awake' ),
							"ca" => __( "Catalan", 'awake' ),
							"zh" => __( "Chinese", 'awake' ),
							"zh_CN" => __( "Chinese (China)", 'awake' ),
							"zh_HK" => __( "Chinese (Hong Kong)", 'awake' ),
							"zh_TW" => __( "Chinese (Taiwan)", 'awake' ),
							"hr" => __( "Croation", 'awake' ),
							"cs" => __( "Czech", 'awake' ),
							"da" => __( "Danish", 'awake' ),
							"nl" => __( "Dutch", 'awake' ),
							"en_IN" => __( "English (India)", 'awake' ),
							"en_IE" => __( "English (Ireland)", 'awake' ),
							"en_SG" => __( "English (Singapore)", 'awake' ),
							"en_ZA" => __( "English (South Africa)", 'awake' ),
							"en_GB" => __( "English (United Kingdom)", 'awake' ),
							"fil" => __( "Filipino", 'awake' ),
							"fi" => __( "Finnish", 'awake' ),
							"fr" => __( "French", 'awake' ),
							"de" => __( "German", 'awake' ),
							"de_CH" => __( "German (Switzerland)", 'awake' ),
							"el" => __( "Greek", 'awake' ),
							"gu" => __( "Gujarati", 'awake' ),
							"iw" => __( "Hebrew", 'awake' ),
							"hi" => __( "Hindi", 'awake' ),
							"hu" => __( "Hungarian", 'awake' ),
							"in" => __( "Indonesian", 'awake' ),
							"it" => __( "Italian", 'awake' ),
							"ja" => __( "Japanese", 'awake' ),
							"kn" => __( "Kannada", 'awake' ),
							"ko" => __( "Korean", 'awake' ),
							"lv" => __( "Latvian", 'awake' ),
							"ln" => __( "Lingala", 'awake' ),
							"lt" => __( "Lithuanian", 'awake' ),
							"ms" => __( "Malay", 'awake' ),
							"ml" => __( "Malayalam", 'awake' ),
							"mr" => __( "Marathi", 'awake' ),
							"no" => __( "Norwegian", 'awake' ),
							"or" => __( "Oriya", 'awake' ),
							"fa" => __( "Persian", 'awake' ),
							"pl" => __( "Polish", 'awake' ),
							"pt_BR" => __( "Portugese (Brazil)", 'awake' ),
							"pt_PT" => __( "Portugese (Portugal)", 'awake' ),
							"ro" => __( "Romanian", 'awake' ),
							"ru" => __( "Russian", 'awake' ),
							"sr" => __( "Serbian", 'awake' ),
							"sk" => __( "Slovak", 'awake' ),
							"sl" => __( "Slovenian", 'awake' ),
							"es" => __( "Spanish", 'awake' ),
							"sv" => __( "Swedish", 'awake' ),
							"gsw" => __( "Swiss German", 'awake' ),
							"ta" => __( "Tamil", 'awake' ),
							"te" => __( "Telugu", 'awake' ),
							"th" => __( "Thai", 'awake' ),
							"tr" => __( "Turkish", 'awake' ),
							"uk" => __( "Ukranian", 'awake' ),
							"vi" => __( "Vietnamese", 'awake' ),
						),
						"type" => "select"
					),
					"shortcode_has_atts" => true,
				)
			);

			return $option;
		}
		
		extract(shortcode_atts(array(
				'size'			=> '',
				'lang'			=> '',
	    ), $atts));
		
		if( is_feed() ) return;
		
	    if ($size != '') { $size = "size='".$size."'"; }
	    if ($lang != '') { $lang = "{lang: '".$lang."'}"; }
	    
		$out = '<div class = "mysite_sociable"><script type="text/javascript" src="https://apis.google.com/js/plusone.js">'.$lang.'</script>';
		$out .= '<g:plusone '.$size.'></g:plusone></div>';
	    		
		return $out;
	}
	
	/**
	 *  Digg button
	 */
	static function digg( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Digg", 'awake' ),
				"value" => "digg",
				"options" => array(
					array(
						"name" => __( "Layout", 'awake' ),
						"id" => "layout",
						"desc" => __( 'Choose how you would like to display the digg button.', 'awake' ),
						"default" => "",
						"options" => array(
							"DiggWide" => __( "Wide", 'awake' ),
							"DiggMedium" => __( "Medium", 'awake' ),
							"DiggCompact" => __( "Compact", 'awake' ),
							"DiggIcon" => __( "Icon", 'awake' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Custom URL", 'awake' ),
						"id" => "url",
						"desc" => __( 'In case you wish to use a different URL you can input it here.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Custom Title", 'awake' ),
						"id" => "title",
						"desc" => __( 'In case you wish to use a different title you can input it here.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Article Type", 'awake' ),
						"id" => "type",
						"desc" => __( 'You can set the article type here for digg.<br /><br />For example if you wanted to set it in the gaming or entertainment topics then you would type this, "gaming, entertainment".', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Custom Description", 'awake' ),
						"id" => "description",
						"desc" => __( 'You can set a custom description to be displayed within digg here.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Related Stories", 'awake' ),
						"id" => "related",
						"desc" => __( 'This option allows you to specify whether links to related stories should be present in the pop up window that may appear when users click the button.', 'awake' ),
						"default" => "",
						"options" => array(
							"true" => __( "Disable related stories?", 'awake' ),
						),
						"type" => "checkbox"
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
				
		extract(shortcode_atts(array(
			'layout'        => 'DiggMedium',
			'url'			=> get_permalink(),
			'title'			=> '',
			'type'			=> '',
			'description'	=> '',
			'related'		=> '',
	    	), $atts));
	
		if( is_feed() ) return;
	    
	    if ($title != '') { $title = "&title='".$title."'"; }
	    if ($type != '') { $type = "rev='".$type."'"; }
	    if ($description != '') { $description = "<span style = 'display: none;'>".$description."</span>"; }
	    if ($related != '') { $related = "&related=no"; }
	    	
		$out = '<div class = "mysite_sociable"><a class="DiggThisButton '.$layout.'" href="http://digg.com/submit?url='.$url.$title.$related.'"'.$type.'>'.$description.'</a>';
		$out .= '<script type = "text/javascript" src = "http://widgets.digg.com/buttons.js"></script></div>';
		
		return $out;
	}
	
	/**
	 *  Stumbleupon button
	 */
	static function stumbleupon( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Stumbleupon", 'awake' ),
				"value" => "stumbleupon",
				"options" => array(
					array(
						"name" => __( "Layout", 'awake' ),
						"id" => "layout",
						"desc" => __( 'Choose how you would like to display the stumbleupon button.', 'awake' ),
						"default" => "",
						"options" => array(
							"1" => __( "Style 1", 'awake' ),
							"2" => __( "Style 2", 'awake' ),
							"3" => __( "Style 3", 'awake' ),
							"4" => __( "Style 4", 'awake' ),
							"5" => __( "Style 5", 'awake' ),
							"6" => __( "Style 6", 'awake' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Custom URL", 'awake' ),
						"id" => "url",
						"desc" => __( 'You can set a custom URL to be displayed within stumbleupon here.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'layout'        => '5',
			'url'			=> '',
	    	), $atts));
	
		if( is_feed() ) return;
	    	
	    if ($url != '') { $url = "&r=".$url; }
	    	
		return '<div class = "mysite_sociable"><script src="http://www.stumbleupon.com/hostedbadge.php?s='.$layout.$url.'"></script></div>';
	}
	
	/**
	 *  Reddit button
	 */
	static function reddit( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Reddit", 'awake' ),
				"value" => "reddit",
				"options" => array(
					array(
						"name" => __( "Layout", 'awake' ),
						"id" => "layout",
						"desc" => __( 'Choose how you would like to display the reddit button.', 'awake' ),
						"default" => "",
						"options" => array(
							"1" => __( "Style 1", 'awake' ),
							"2" => __( "Style 2", 'awake' ),
							"3" => __( "Style 3", 'awake' ),
							"4" => __( "Style 4", 'awake' ),
							"5" => __( "Style 5", 'awake' ),
							"6" => __( "Style 6", 'awake' ),
							"7" => __( "Interactive 1", 'awake' ),
							"8" => __( "Interactive 2", 'awake' ),
							"9" => __( "Interactive 3", 'awake' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Custom URL", 'awake' ),
						"id" => "url",
						"desc" => __( 'You can set a custom URL to be displayed with your button instead of the current page.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Custom Title", 'awake' ),
						"id" => "title",
						"desc" => __( 'If using the interactive buttons you can specify a custom title to use here.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Styling", 'awake' ),
						"id" => "disablestyle",
						"desc" => __( 'Checking this will disable the reddit styling used for the button.', 'awake' ),
						"default" => "",
						"options" => array(
							"true" => __( "Disable reddit styling?", 'awake' ),
						),
						"type" => "checkbox"
					),
					array(
						"name" => __( "Target", 'awake' ),
						"id" => "target",
						"desc" => __( 'Select the target for this button.', 'awake' ),
						"default" => "",
						"options" => array(
							"true" => __( "Display in new window?", 'awake' ),
						),
						"type" => "checkbox"
					),
					array(
						"name" => __( "Community", 'awake' ),
						"id" => "community",
						"desc" => __( 'If using the interactive buttons you can specify a community to target here.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'layout'        => '8',
			'url'			=> '',
			'disablestyle'	=> '',
			'target'		=> '',
			'community'		=> '',
			'title'			=> '',
	    	), $atts));
	
		if( is_feed() ) return;
	    	
	    if ($disablestyle != '') { $disablestyle = "&styled=off"; }
	    if ($target != '') { $target = "&newwindow=1"; }
	    if ($layout == '7' || $layout == '8' || $layout == '9') { $url = "reddit_url='".$url."';"; } else { if ($url != '') { $url = "&url='".$url."'"; } }
	    if ($title != '') { $title = "reddit_title='".$title."';"; }
	    if ($community != '') { $community = "reddit_target='".$community."';"; }
	    if ($layout == '7' || $layout == '8' || $layout == '9') { $target = "reddit_newwindow='1';"; }
	    	
		switch ($layout)
		{
			case 1: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=0'.$disablestyle.$url.$target.'"></script></div>'; break;
			case 2: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=1'.$disablestyle.$url.$target.'"></script></div>'; break;		
			case 3: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=2'.$disablestyle.$url.$target.'"></script></div>'; break;		
			case 4: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=3'.$disablestyle.$url.$target.'"></script></div>'; break;		
			case 5: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=4'.$disablestyle.$url.$target.'"></script></div>'; break;		
			case 6: return '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/buttonlite.js?i=5'.$disablestyle.$url.$target.'"></script></div>'; break;	
			case 7: $out = '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/static/button/button1.js"></script>'; 
					$out .= '<script type = "text/javascript">'.$url.$title.$community.$target.'</script></div>';
					return $out; break;
			case 8: $out = '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/static/button/button2.js"></script>';
					$out .= '<script type = "text/javascript">'.$url.$title.$community.$target.'</script></div>';
					return $out; break;
			case 9: $out = '<div class = "mysite_sociable"><script type="text/javascript" src="http://www.reddit.com/static/button/button3.js"></script>'; 
					$out .= '<script type = "text/javascript">'.$url.$title.$community.$target.'</script></div>';
					return $out; break;	
		}
	}
	
	/**
	 *  LinkedIn button
	 */
	static function linkedin( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "LinkedIn", 'awake' ),
				"value" => "linkedin",
				"options" => array(
					array(
						"name" => __( "Layout", 'awake' ),
						"id" => "layout",
						"desc" => __( 'Choose how you would like to display the linkedin button.', 'awake' ),
						"default" => "",
						"options" => array(
							"1" => __( "Style 1", 'awake' ),
							"2" => __( "Style 2", 'awake' ),
							"3" => __( "Style 3", 'awake' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Custom URL", 'awake' ),
						"id" => "url",
						"desc" => __( 'You can set a custom URL to be displayed within linkedin here.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'layout'        => '3',
			'url'			=> '',
	    	), $atts));
	
		if( is_feed() ) return;
	    	
	    if ($url != '') { $url = "data-url='".$url."'"; }
	    if ($layout == '2') { $layout = 'right'; }
		if ($layout == '3') { $layout = 'top'; }
	    	
		return '<div class = "mysite_sociable"><script type="text/javascript" src="http://platform.linkedin.com/in.js"></script><script type="in/share" data-counter = "'.$layout.'" '.$url.'></script></div>';
	}
	
	/**
	 *  Delicious button
	 */
	static function delicious( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Delicious", 'awake' ),
				"value" => "delicious",
				"options" => array(
					array(
						"name" => __( "Custom Text", 'awake' ),
						"id" => "text",
						"desc" => __( 'You can set some text to display alongside your delicious button.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'text'			=> '',
	    ), $atts));
	
		if( is_feed() ) return;
	    	
		return '<div class = "mysite_sociable"><img src="http://www.delicious.com/static/img/delicious.small.gif" height="10" width="10" alt="Delicious" />&nbsp;<a href="http://www.delicious.com/save" onclick="window.open(&#39;http://www.delicious.com/save?v=5&noui&jump=close&url=&#39;+encodeURIComponent(location.href)+&#39;&title=&#39;+encodeURIComponent(document.title), &#39;delicious&#39;,&#39;toolbar=no,width=550,height=550&#39;); return false;">'.$text.'</a></div>';
	}
	
	/**
	 *  Pinterest button
	 */
	static function pinterest( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				"name" => __( "Pinterest", 'awake' ),
				"value" => "pinterest",
				"options" => array(
					array(
						"name" => __( "Description", 'awake' ),
						"id" => "text",
						"desc" => __( 'You can set some text to display alongside your Pinterest button.', 'awake' ),
						"default" => "",
						"type" => "text"
					),
					array(
						"name" => __( "Layout", 'awake' ),
						"id" => "layout",
						"desc" => __( 'Choose how you would like to display the Pinterest button.', 'awake' ),
						"default" => "",
						"options" => array(
							"horizontal" => __( "Horizontal", 'awake' ),
							"vertical" => __( "Vertical", 'awake' ),
							"none" => __( "None", 'awake' ),
						),
						"type" => "select"
					),
					array(
						"name" => __( "Image URL", 'awake' ),
						"id" => "image",
						"desc" => __( 'Paste the URL of the image you want to be pinned here.', 'awake' ),
						"default" => "",
						"type" => "text",
					),
					array(
						"name" => __( "Auto Prompt", 'awake' ),
						"id" => "prompt",
						"desc" => __( 'Check this if you wish to have a prompt display to select your image when clicking on the Pinterest button. This will disable the count bubble.', 'awake' ),
						"options" => array( "true" => __( "Use Auto Prompt", 'awake' ) ),  
						"default" => "",
						"type" => "checkbox",
					),
					"shortcode_has_atts" => true,
				)
			);			
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'text'			=> '',
			'layout'		=> '',
			'image'			=> '',
			'url'			=> '',
			'prompt'	=> '',
	    ), $atts));
	
		if( is_feed() ) return;
	    	
		if ($url == '') { $url = get_permalink(); }
		if ($layout == '') { $layout = 'horizontal'; }
			
		$out = '<div class = "mysite_sociable"><a href="http://pinterest.com/pin/create/button/?url='.$url.'&media='.$image.'&description='.$text.'" class="pin-it-button" count-layout="'.$layout.'">Pin It</a>';
		$out .= '<script type="text/javascript" src="http://assets.pinterest.com/js/pinit.js"></script></div>';
		
		if ( $prompt ) {
			$out = '<div class = "mysite_sociable"><a title="Pin It on Pinterest" class="pin-it-button" href="javascript:void(0)">pin it</a>';
			$out .= '<script type = "text/javascript">';
			$out .= 'jQuery(document).ready(function(){';
				$out .= 'jQuery(".pin-it-button").click(function(event) {';
				$out .= 'event.preventDefault();';
				$out .= 'jQuery.getScript("http://assets.pinterest.com/js/pinmarklet.js?r=" + Math.random()*99999999);';
				$out .= '});';
			$out .= '});';
			$out .= '</script>';
			$out .= '<style type = "text/css">a.pin-it-button {position: absolute;background: url(http://assets.pinterest.com/images/pinit6.png);font: 11px Arial, sans-serif;text-indent: -9999em;font-size: .01em;color: #CD1F1F;height: 20px;width: 43px;background-position: 0 -7px;}a.pin-it-button:hover {background-position: 0 -28px;}a.pin-it-button:active {background-position: 0 -49px;}</style></div>';
		}
			
		return $out;
	}
	
	/**
	 *
	 */
	static function _options( $class ) {
		$shortcode = array();
		
		$class_methods = get_class_methods( $class );
		
		foreach( $class_methods as $method ) {
			if( $method[0] != '_' )
				$shortcode[] = call_user_func(array( &$class, $method ), $atts = 'generator' );
		}
		
		$options = array(
			"name" => __( 'Social', 'awake' ),
			'desc' => __( 'Choose which type of social button you wish to use.', 'awake' ),
			"value" => "social",
			"options" => $shortcode,
			"shortcode_has_types" => true
		);
		
		return $options;
	}
}

?>