<?php
/**
 *
 */
class mysiteHighlights {
	
	/**
	 *
	 */
	static function highlight1( $atts = null, $content = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Highlight 1', 'awake' ),
				'value' => 'highlight1',
				'options' => array(
					array(
						'name' => __( 'Highlight Text', 'awake' ),
						'desc' => __( 'Type out the text that you wish to display with your highlight.', 'awake' ),
						'id' => 'content',
						'default' => '',
						'type' => 'textarea'
					),
					array(
						'name' => __( 'Color Variation <small>(optional)</small>', 'awake' ),
						'desc' => __( 'Choose one of our predefined color skins to use with your highlight.', 'awake' ),
						'id' => 'variation',
						'default' => '',
						'target' => 'color_variations',
						'type' => 'select'
					),
					array(
						'name' => __( 'Custom BG Color <small>(optional)</small>', 'awake' ),
						'desc' => __( 'Or you can also choose your own color to use as the background for your highlight.', 'awake' ),
						'id' => 'bgColor',
						'type' => 'color'
					),
					array(
						'name' => __( 'Custom Text Color <small>(optional)</small>', 'awake' ),
						'desc' => __( 'You can change the color of the text that appears on your highlight.', 'awake' ),
						'id' => 'textColor',
						'type' => 'color'
					),
				'shortcode_has_atts' => true
				)
			);
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'variation'	=> '',
			'bgcolor'	=> '',
			'textcolor'	=> ''
	    ), $atts));
	
		$variation = ( ( $variation ) && ( empty( $bgcolor ) ) ) ? ' ' . trim( $variation ) : '';
		
		$styles = array();
		
		if( $bgcolor )
			$styles[] = 'background-color:' . $bgcolor . ';border-color:' . $bgcolor . ';';
			
		if( $textcolor )
			$styles[] = 'color:' . $textcolor . ';';
			
		$style = join( '', array_unique( $styles ) );
		$style = ( !empty( $style ) ) ? ' style="' . $style . '"': '' ;
			
		return '<span class="highlight' . $variation . '"' . $style . '>' . mysite_remove_wpautop( $content ) . '</span>';
	}
	
	/**
	 *
	 */
	static function highlight2( $atts = null, $content = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Highlight 2', 'awake' ),
				'value' => 'highlight2',
				'options' => array(
					array(
						'name' => __( 'Highlight Text', 'awake' ),
						'desc' => __( 'Type out the text that you wish to display with your highlight.', 'awake' ),
						'id' => 'content',
						'default' => '',
						'type' => 'textarea'
					),
					array(
						'name' => __( 'Color Variation <small>(optional)</small>', 'awake' ),
						'desc' => __( 'Choose one of our predefined color skins to use with your highlight.', 'awake' ),
						'id' => 'variation',
						'default' => '',
						'target' => 'color_variations',
						'type' => 'select'
					),
					array(
						'name' => __( 'Custom Text Color <small>(optional)</small>', 'awake' ),
						'desc' => __( 'You can change the color of the text that appears on your highlight.', 'awake' ),
						'id' => 'textColor',
						'type' => 'color'
					),
				'shortcode_has_atts' => true
				)
			);
			
			return $option;
		}
		
		extract(shortcode_atts(array(
			'variation'	=> '',
			'textcolor'	=> ''
	    ), $atts));
	
		$variation = ( ( $variation ) && ( empty( $textcolor ) ) ) ? ' ' . trim( $variation ) . '_text' : '';
			
		$style = ( !empty( $textcolor ) ) ? ' style="color:' . $textcolor . ';"': '' ;
			
		return '<span class="highlight2' . $variation . '"' . $style . '>' . mysite_remove_wpautop( $content ) . '</span>';
	}
	
	/**
	 *
	 */
	static function highlight3( $atts = null, $content = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Highlight 3', 'awake' ),
				'value' => 'highlight3',
				'options' => array(
					array(
						'name' => __( 'Highlight Text', 'awake' ),
						'desc' => __( 'Type out the text that you wish to display with your highlight.', 'awake' ),
						'id' => 'content',
						'default' => '',
						'type' => 'textarea'
					),
				'shortcode_has_atts' => true
				)
			);

			return $option;
		}

		extract(shortcode_atts(array(
			'css' 		=> '',
			'classes' 	=> '',
		), $atts));

		if ( !empty( $css ) )
			$css = ' style="' . $css . '"';
			
		if ( !empty( $classes ) )
			$classes = ' ' . $classes;

		return '<span class="highlight3' . $classes . '"' . $css . '>' . mysite_remove_wpautop( do_shortcode( $content ) ) . '</span>';
	}

	/**
	 *
	 */
	static function highlight4( $atts = null, $content = null ) {
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Highlight 4', 'awake' ),
				'value' => 'highlight4',
				'options' => array(
					array(
						'name' => __( 'Highlight Text', 'awake' ),
						'desc' => __( 'Type out the text that you wish to display with your highlight.', 'awake' ),
						'id' => 'content',
						'default' => '',
						'type' => 'textarea'
					),
				'shortcode_has_atts' => true
				)
			);

			return $option;
		}

		extract(shortcode_atts(array(
			'css' 		=> '',
			'classes' 	=> '',
		), $atts));

		if ( !empty( $css ) )
			$css = ' style="' . $css . '"';
			
		if ( !empty( $classes ) )
			$classes = ' ' . $classes;

		return '<span class="highlight4' . $classes . '"' . $css . '>' . mysite_remove_wpautop( do_shortcode( $content ) ) . '</span>';
	}
	
	/**
	 *
	 */
	static function _options( $class ) {
		$shortcode = array();
		
		$class_methods = get_class_methods( $class );
		
		foreach( $class_methods as $method ) {
			if( $method[0] != '_' )
				$shortcode[] = call_user_func(array( &$class, $method ), $atts = 'generator' );
		}
		
		$options = array(
			'name' => __( 'Highlights', 'awake' ),
			'desc' => __( 'Choose which type of highlight you wish to use.', 'awake' ),
			'value' => 'highlights',
			'options' => $shortcode,
			'shortcode_has_types' => true
		);
		
		return $options;
	}
	
}

?>