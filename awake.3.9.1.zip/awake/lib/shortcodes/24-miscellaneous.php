<?php
/**
 *
 */
class mysiteMiscellaneous {

	/**
	 *
	 */
	static function fancy_amp( $atts = null, $content = null ) {
	
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Fancy Amp', 'awake' ),
				'value' => 'fancy_amp'
			);

			return $option;
		}
		
		return '<span class="fancy_amp">&amp;</span>';
	}

	/**
	 *
	 */
	static function divider( $atts = null, $content = null, $code = null ) {
		
		if( $atts == 'generator' ) {
			$option = array(
				'name' => __( 'Divider', 'awake' ),
				'value' => 'divider'
			);

			return $option;
		}
			
		return '<div class="divider"></div>';
	}
	
	/**
	 *
	 */
	static function divider_top( $atts = null, $content = null, $code = null ) {
		
		if( $atts == 'generator' ) {
			$option = array(
				'name' => __( 'Divider Top', 'awake' ),
				'value' => 'divider_top'
			);

			return $option;
		}
			
		return '<div class="divider top"><a href="#">' . __( 'Top', 'awake' ) . '</a></div>';
	}
	
	/**
	 *
	 */
	static function clearboth( $atts = null, $content = null, $code = null ) {
		
		if( $atts == 'generator' ) {
			$option = array(
				'name' => __( 'Clearboth', 'awake' ),
				'value' => 'clearboth'
			);

			return $option;
		}
			
		return '<div class="clearboth"></div>';
	}
	
	/**
	 *
	 */
	static function div( $atts = null, $content = null, $code = null ) {
		$option = array( 
			'name' => __( 'Div', 'awake' ),
			'value' => 'div',
			'options' => array(
				array(
					'name' => __( 'Class', 'awake' ),
					'desc' => __( 'Type in the name of the class you wish to assign to this div.', 'awake' ),
					'id' => 'class',
					'default' => '',
					'type' => 'text'
				),
				array(
					'name' => __( 'Style', 'awake' ),
					'desc' => __( 'You can set a custom style here for your div.', 'awake' ),
					'id' => 'style',
					'default' => '',
					'type' => 'text'
				),
				array(
					'name' => __( 'Content', 'awake' ),
					'desc' => __( 'Type in the content that you wish to display inside this div.', 'awake' ),
					'id' => 'content',
					'default' => '',
					'type' => 'textarea'
				),
			'shortcode_has_atts' => true,
			)
		);
		
		if( $atts == 'generator' )
			return $option;
			
		extract(shortcode_atts(array(
			'style'      => '',
			'class'      => '',
	    	), $atts));

	   return '<div class="' . $class . '" style="' . $style . '">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function span( $atts = null, $content = null, $code = null ) {
		$option = array( 
			'name' => __( 'Span', 'awake' ),
			'value' => 'span'
		);
		
		if( $atts == 'generator' )
			return $option;
			
		extract(shortcode_atts(array(
			'style'      => '',
			'class'      => '',
	    	), $atts));

	   return '<span class="' . $class . '" style="' . $style . '">' . mysite_remove_wpautop( $content ) . '</span>';
	}
	
	/**
	 *
	 */
	static function teaser( $atts = null, $content = null ) {

		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Teaser', 'awake' ),
				'value' => 'teaser'
			);

			return $option;
		}

		return '<p class="teaser"><span>' . mysite_remove_wpautop( $content ) . '</span></p>';
	}
	
	/**
	 *
	 */
	static function hidden( $atts = null, $content = null ) {

		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'Hidden', 'awake' ),
				'value' => 'hidden'
			);

			return $option;
		}

		return '<div class="hidden">' . mysite_remove_wpautop( $content ) . '</div>';
	}

	/**
	 *
	 */
	static function margin10( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin10', 'awake' ),
				'value' => 'margin10'
			);

			return $option;
		}
			
		return '<div class="margin10">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin20( $atts = null, $content = null ) {

		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin20', 'awake' ),
				'value' => 'margin20'
			);

			return $option;
		}
			
		return '<div class="margin20">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin30( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin30', 'awake' ),
				'value' => 'margin30'
			);

			return $option;
		}
			
		return '<div class="margin30">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin40( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin40', 'awake' ),
				'value' => 'margin40'
			);

			return $option;
		}
			
		return '<div class="margin40">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin50( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin50', 'awake' ),
				'value' => 'margin50'
			);

			return $option;
		}
		
		return '<div class="margin50">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin60( $atts = null, $content = null ) {

		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin60', 'awake' ),
				'value' => 'margin60'
			);

			return $option;
		}
			
		return '<div class="margin60">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin70( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin70', 'awake' ),
				'value' => 'margin70'
			);

			return $option;
		}
			
		return '<div class="margin70">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin80( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin80', 'awake' ),
				'value' => 'margin80'
			);

			return $option;
		}
			
		return '<div class="margin80">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function margin90( $atts = null, $content = null ) {
			
		if( $atts == 'generator' ) {
			$option = array( 
				'name' => __( 'margin90', 'awake' ),
				'value' => 'margin90'
			);

			return $option;
		}
		
		return '<div class="margin90">' . mysite_remove_wpautop( $content ) . '</div>';
	}
	
	/**
	 *
	 */
	static function mobile_only( $atts = null, $content = null ) {
		
		$option = array( 
			'name' => __( 'Mobile Only', 'awake' ),
			'value' => 'mobile_only',
			'options' => array(
				array(
					'name' => __( 'Content', 'awake' ),
					'desc' => __( 'Type in the content that you wish to display on a mobile device only.', 'awake' ),
					'id' => 'content',
					'default' => '',
					'type' => 'textarea'
				),
			'shortcode_has_atts' => true,
			)
		);
		
		if( $atts == 'generator' )
			return $option;
			
		extract(shortcode_atts(array(
		), $atts));

		global $mysite;

		if( !isset( $mysite->mobile ) )
			$content = '';

		return $content;
	}

	/**
	 *
	 */
	static function _options( $class ) {
		$shortcode = array();
		
		$class_methods = get_class_methods( $class );
		
		foreach( $class_methods as $method ) {
			if( $method[0] != '_' )
				$shortcode[] = call_user_func(array( &$class, $method ), $atts = 'generator' );
		}
		
		$options = array(
			'name' => __( 'Miscellaneous', 'awake' ),
			'desc' => __( 'Select which Miscellaneous shortcode you wish to use.', 'awake' ),
			'value' => 'miscellaneous',
			'options' => $shortcode,
			'shortcode_has_types' => true
		);
		
		return $options;
	}
	
}

?>