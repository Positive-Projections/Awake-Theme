<?php

$meta_boxes = array(
	'title' => sprintf( __( 'Testimonial Details', 'awake' ), THEME_NAME ),
	'id' => 'mysite_testimonial_meta_box',
	'pages' => array( 'testimonial' ),
	'callback' => '',
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array(
			'name' => __( 'Image', 'awake' ),
			'desc' => __( 'Select the type of image you\'d liked displayed with your testimonial.', 'awake' ),
			'id' => '_image',
			'options' => array( 
				'use_gravatar' => __( 'Use Gravatar', 'awake' ),
				'upload_picture' => __( 'Upload Picture', 'awake' ),
				'no_image' => __( 'No Image', 'awake' )
			),
			'toggle' => 'toggle_true',
			'type' => 'radio'
		),
		array(
			'name' => __( 'Custom Image', 'awake' ),
			'desc' => __( 'Upload an image to use for this testimonial.', 'awake' ),
			'id' => '_custom_image',
			'toggle_class' => '_image_upload_picture',
			'type' => 'upload'
		),
		array(
			'name' => __( 'Email <small>(for Gravatar support)</small>', 'awake' ),
			'desc' => __( 'Enter the email address for the Gravatar you\'d like displayed, if no Gravatar is found your themes default will be used.', 'awake' ),
			'id' => '_email',
			'toggle_class' => '_image_use_gravatar',
			'type' => 'text'
		),
		array(
			'name' => __( 'Name', 'awake' ),
			'desc' => __( 'Enter the name for this testimonial.', 'awake' ),
			'id' => '_name',
			'type' => 'text'
		),
		array(
			'name' => __( 'Website Name', 'awake' ),
			'desc' => __( 'Enter the website name for this testimonial.', 'awake' ),
			'id' => '_website_name',
			'type' => 'text'
		),
		array(
			'name' => __( 'Website URL', 'awake' ),
			'desc' => __( 'Enter the website url for this testimonial.', 'awake' ),
			'id' => '_website_url',
			'type' => 'text'
		),
		array(
			'name' => __( 'Testimonial', 'awake' ),
			'desc' => __( 'Enter your testimonial.', 'awake' ),
			'id' => '_testimonial',
			'no_header' => true,
			'type' => 'editor'
		),
	)
);
return array(
	'load' => true,
	'options' => $meta_boxes
);

?>