<?php
/**
 * Sets up the theme by loading the Mysitemyway class & initializing the framework
 * which activates all classes and functions needed for theme's operation.
 *
 * @package Mysitemyway
 * @subpackage Functions
 */

//-----------since 3.9.1------------
if ( ! isset( $content_width ) ) {
	$content_width = 900;
}
if ( ! function_exists( 'awake_setup' ) ) :
function awake_setup() {

	/*
	 * Make awake available for translation.
	 *
	 * Translations can be added to the /languages/ directory.
	 * If you're building a theme based on catalog, use a find and
	 * replace to change THEMESNAME to the name of your theme in all
	 * template files.
	 */
	

	// This theme styles the visual editor to resemble the theme style.
	add_editor_style( array( 'editor-style.css') );

	// Add RSS feed links to <head> for posts and comments.
	add_theme_support( 'automatic-feed-links' );

	// Enable support for Post Thumbnails, and declare two sizes.
	add_theme_support( 'post-thumbnails' );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

	/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats
	 */
	//add_theme_support( 'post-formats', array( 'quote', 'link', 'gallery' ) );

	// This theme uses its own gallery styles.
	add_filter( 'use_default_gallery_style', '__return_false' );
	
	add_theme_support( 'title-tag' );

}
endif; // catalog_setup
add_action( 'after_setup_theme', 'awake_setup' );

# Load the Mysitemyway class.
require_once( get_template_directory() . '/framework.php' );

# Get theme data.
//$theme_data = get_theme_data( TEMPLATEPATH . '/style.css' );

# Initialize the Mysitemyway framework.
Mysitemyway::init(array(
	'theme_name' => 'Awake',
	'theme_version' => '3.9.1'
));

function awake_scripts() {
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ){
		wp_enqueue_script( 'comment-reply' );
	}
	
}
add_action( 'wp_enqueue_scripts', 'awake_scripts' );

?>